

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mrahman
 */
public class SnakeEyeGame {
    public static void main(String[] args) {
        Player p1 = new Player("Computer [AI]");
        Player p2 = new Player("Player2 -[You]"); 
        Controller c = new Controller(p1,p2);
        c.startGame();
    }
    
}
