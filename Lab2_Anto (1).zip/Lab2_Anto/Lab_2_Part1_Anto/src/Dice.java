

import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mrahman
 */
class Die {
    private int face;
    Random rnd;
    Die(){
        rnd = new Random();
        face = 1;
    }
    
    public int roll(){
        return (rnd.nextInt(6)+1);
    } 
	public int roll1(int inp)
	{
	return (rnd.nextInt(inp)+1);

	}

    public int getFace() {
        return face;
    }

    @Override
    public String toString() {
        return "Die{" + "face=" + face + '}';
    }
    
    
    
    
}
public class Dice {
    Die die1,die2; 
    Dice(){
        die1 = new Die();
        die2 = new Die();
    }
    
    public int roll(){
        return die1.roll() + die2.roll();
    }
public int roll1(int inp){
        return die1.roll1(inp) + die2.roll1(inp);
    }

    @Override
    public String toString() {
        return "Dice{" + "die1=" + die1 + ", die2=" + die2 + '}';
    }
    
    
    
}