



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mrahman
 */
public class Controller {

    private Player player1, player2;
    private Dice dice;
    private ScoreBoard scoreBoard;
    private final int PLAYING = 0;
    private final int WINNER = 1;

    private int gameState;

    public Controller(Player p1, Player p2) {
        player1 = p1;
        player2 = p2;
        dice = new Dice();
        gameState = -1;
        scoreBoard = new ScoreBoard();
    }

    private void updateGameState(Player p) {
        if (p.getScore() > 100) {
            gameState = WINNER;
            scoreBoard.showWinnner(p.toString());
        }

    }

    public void startGame() {
        gameState = PLAYING;

        while (gameState == PLAYING) {
           // while (gameState == PLAYING) {
                player1.takeTurn(dice,"pl1");
                updateGameState(player1);
                
                if(gameState == WINNER){
                 scoreBoard.showWinnner(player1.toString() + " is the Winner!");
                 break;
                }
                int sc = player1.getScore();
                scoreBoard.updateScoreBoard(player1.toString());
                
                /*if (player1.takeAnotherTurn() == false) {
                    break;
                }*/
            //}

           // while (gameState == PLAYING) {
           
                player2.takeTurn(dice,"pl2");
                //int sc = player1.getScore();
                
                updateGameState(player2);
                if(gameState == WINNER){
                 scoreBoard.showWinnner(player2.toString() + " is the Winner!");
                 
                }
                scoreBoard.updateScoreBoard(player2.toString());
                  if(player1.getScore()> 19 && player2.getScore()<10){
                   if( player2.takeAnotherTurn() == true){
                       
                   }
                  }
                
            }
        }
}

    

