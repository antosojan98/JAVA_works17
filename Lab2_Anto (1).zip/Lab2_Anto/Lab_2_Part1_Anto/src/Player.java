

/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mrahman
 */

import java.util.*;

public class Player {

    private String name;
    private int score;
	public int result;

    Player(String name) {
        score = 0;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void updateScore(int score) {
        this.score = score;
    }

    public void takeTurn(Dice d,String pl) {
        // roll dice
        // update score based on roll values
		if(pl=="pl1"){
        result = d.roll();
}
		else
		{
Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter a number you wish to get from rolling one die :");
        
        int inp = scan.nextInt();
        if(inp <= 6 && inp >= 1)
            
	 result = d.roll1(inp);
        
        else{
            
         System.out.println("Error : A die has only 6 sides!! : please enter a number between 1 to 6.");
         System.out.println();
         System.out.println("Sorry: YOU HAVE MISSED YOUR TURN.");
         System.out.println();
        }
}
         System.out.println("Player rolled a sum : "+ result);
        if (result == 2) {
            updateScore(0);
        } else if (result != 9) {
            this.updateScore(result + getScore());
        }

    }

    public boolean takeAnotherTurn() {
        Scanner scan = new Scanner(System.in);
     
        System.out.println("Computer [AI] is way ahead !! Would you like to take another turn?(y/n)");
        
        String input = scan.next();
        
        if(input.equalsIgnoreCase("y"))
            return true;
        else 
        return false;
	

    }

    @Override
    public String toString() {
        return "Player{" + "player =  " + name + ", Current Score = " + score + '}';
    }

}

