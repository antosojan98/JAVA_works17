/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ANTO AWESOME
 */
public class AddressBookTestClint {

    public static void main(String[] args) {
        AddressBook ab1 = new AddressBook();
        AddressBookEntry add1 = new AddressBookEntry(" Tonny ", " McGill st", " tonie@gmail.com ", " 122-333-4443 ");
        AddressBookEntry add2 = new AddressBookEntry(" Jimmy ", " Coll Dr ", " jim@gmail.com ", " 122-533-1233 ");
        AddressBookEntry add3 = new AddressBookEntry(" Ray TT ", " Columbia ", " rays@gmail.com ", " 122-113-4093 ");
        AddressBookEntry add4 = new AddressBookEntry(" Rohan ", " Aberdeen ", " rohan1289@gmail.com ", " 122-004-1233 ");
        System.out.println(ab1.addEntry(add1));
        System.out.println();
        System.out.println(ab1.addEntry(add2));
        System.out.println();
        System.out.println(ab1.addEntry(add3));
        System.out.println();
        System.out.println(ab1.addEntry(add4));
        System.out.println();
        ab1.UpdateEntry(3, " poly ", " McGill Rd ", " poly@tru.cs ", " 211-124-1234 ");
        ab1.UpdateEntry(1, " ravi ", " kelowna ", " ravi@gmail.com ", " 233-445-6433 ");
        System.out.println(ab1.deleteEntry(2));
        System.out.println(ab1.deleteEntry(3));
        ab1.UpdateEntry(2, " sony ", " NewYork ", " sony243@gmail.com ", " 123-432-2345 ");
        ab1.ViewAll();
        System.out.println(ab1.toString());
        if(ab1.deleteEntry(1)){
            System.out.println("entry deleted");
        }
        ab1.ViewAll();
        System.out.println(ab1);
    }
}
