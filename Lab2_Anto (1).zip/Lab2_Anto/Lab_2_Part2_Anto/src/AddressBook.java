/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ANTO AWESOME
 */
public class AddressBook {

    private AddressBookEntry[] entries = new AddressBookEntry[100];

    public boolean addEntry(AddressBookEntry add) {
        int x = entries.length;
        entries = add(entries, add);
        if (entries.length > x) {
            return true;
        }
        return false;
    }

    public static AddressBookEntry[] add(AddressBookEntry[] originalArray, AddressBookEntry newItem) {
        int currentSize = originalArray.length;
        int newSize = currentSize + 1;
        AddressBookEntry[] tempArray = new AddressBookEntry[newSize];
        for (int i = 0; i < currentSize; i++) {
            tempArray[i] = originalArray[i];

        }
        tempArray[newSize - 1] = newItem;
        return tempArray;
    }

    public boolean deleteEntry(int index) {
        int j = entries.length;
        entries[index - 1] = new AddressBookEntry();
        if (entries.length == j) {
            return true;
        }
        return false;
    }

    public void ViewAll() {

        for (int i = 0; i < entries.length; i++) {
            if (entries[i] != null) {
                System.out.println(entries[i]);

            }
        }
    }

    public void UpdateEntry(int index, String name, String address, String phone, String email) {
        entries[index - 1] = new AddressBookEntry(name, address, phone, email);

    }
}
