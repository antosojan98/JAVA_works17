/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ANTO AWESOME
 */
public class AddressBookEntry {

    private String Name, Address, EmailAddress;
    private String TelephoneNumber;

    public AddressBookEntry() {
        this.Name = "NoName";
        this.Address = "NoAddressYet";
        this.EmailAddress = "NoEmailYet";
        this.TelephoneNumber = "000-000-0000";

    }

    public AddressBookEntry(String Name, String Address, String EmailAddress, String TelephoneNumber) {
        this.Name = Name;
        this.Address = Address;
        this.EmailAddress = EmailAddress;
        this.TelephoneNumber = TelephoneNumber;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String EmailAddress) {
        this.EmailAddress = EmailAddress;
    }

    public String getTelephoneNumber() {
        return TelephoneNumber;
    }

    public void setTelephoneNumber(String TelephoneNumber) {
        this.TelephoneNumber = TelephoneNumber;
    }

    @Override
    public String toString() {
        return  " Name = " + Name + ",\t Address = " + Address + ",\t TelephoneNumber = " + TelephoneNumber + ",\tEmailAddress = " + EmailAddress ;
    }

}
